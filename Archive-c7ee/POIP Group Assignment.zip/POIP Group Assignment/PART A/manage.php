<?php
	session_start();
	if(!isset($_SESSION['islogin']) && $_SESSION['firstlogin']==0){
		$_SESSION['kickOut'] = "kick";
		header('Location:index.php');
	} 

	header('location:managepassword.php');
 ?>