<?php 
	include 'verficationEPUser.php';

	require_once 'conn.php';
	$uid = $_SESSION['userID'];
	$sql = "SELECT * FROM request JOIN item ON request.iid=item.iid JOIN measure ON item.mid=measure.mid WHERE monthly=0 AND uid='$uid'";
	$result = mysqli_query($link,$sql);
	$sql1 = "SELECT * FROM request JOIN item ON request.iid=item.iid JOIN measure ON item.mid=measure.mid WHERE monthly=1 AND uid='$uid'";
	$result1 = mysqli_query($link,$sql1);

	require './html/item.html';
 ?>