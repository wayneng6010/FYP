<?php
	include 'verficationEP.php';
	
	require_once 'conn.php';
	$sql = "SELECT * FROM soreport,user,requestsout,measure,item WHERE requestsout.sorid=soreport.sorid AND measure.mid=item.mid AND user.uid=requestsout.uid AND item.iid=requestsout.iid ORDER BY iname";
	$result = mysqli_query($link,$sql);


	$sql1 = "SELECT SUM(quantity) As total,iname,mname FROM (SELECT DISTINCT sid, iname,quantity,mname,expire FROM stock,item,requestsout,soreport,measure WHERE requestsout.sorid=soreport.sorid AND measure.mid=item.mid AND item.iid=requestsout.iid AND requestsout.iid=stock.iid AND expire>now()) As t GROUP BY iname";
	$result1 = mysqli_query($link,$sql1);


	if(isset($_POST['search'])){
		$date = $_POST['date'];
		$quan = $_POST['quan'];
		$item = $_POST['item'];
		$item = mysqli_real_escape_string($link,$item);
		$item = htmlentities($item, ENT_QUOTES, "UTF-8");
		$date = date("Y-m-d", strtotime($date));
		(($quan=="HL")? $quan="DESC":$quan="ASC");
		$sql2 = "SELECT * FROM soreport,user,requestsout,measure,item WHERE requestsout.sorid=soreport.sorid AND measure.mid=item.mid AND user.uid=requestsout.uid AND item.iid=requestsout.iid AND item.iname LIKE '%$item%' AND stockoutDate='$date' ORDER BY stockoutQuan $quan";
		$result2 = mysqli_query($link,$sql2);
	}


	require './html/stockOutReport.html';
 ?>