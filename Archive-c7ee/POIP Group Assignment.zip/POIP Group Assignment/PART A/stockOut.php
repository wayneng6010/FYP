<?php
	session_start();
	if(!isset($_SESSION['islogin'])){
		$_SESSION['kickOut'] = "kick";
		header('Location:index.php');
	} 
	require_once 'conn.php';
?>

<?php
		

	if(isset($_POST['add'])){
		$item = $_POST['item'];
		$quantity = $_POST['quantity'];
		$exp = $_POST['exp'];
		$sql2 = "INSERT INTO stock VALUES (NULL, '$item', '$quantity', '$exp', 1)";
		if($queryResult = mysqli_query($link, $sql2)){
			echo "<script>alert('Stock up successful');</script>";
		}
		else{
			echo "<script>alert('Failed');</script>";
		}
	}

	if(isset($_GET['sorid'])){
		$sorid = $_GET['sorid'];
		$query1 = "SELECT * FROM item,requestsout WHERE requestsout.iid=item.iid AND requestsout.sorid='$sorid'";
		$result1 = mysqli_query($link,$query1);
		$query3 = "SELECT * FROM item,requestsout WHERE requestsout.iid=item.iid AND requestsout.sorid='$sorid'";
		$result3 = mysqli_query($link,$query1);
		$query6 = "SELECT * FROM item,requestsout WHERE requestsout.iid=item.iid AND requestsout.sorid='$sorid'";
		$result6 = mysqli_query($link,$query1);
		// $query5 = "SELECT * FROM item,requestsout WHERE requestsout.iid=item.iid AND requestsout.sorid='$sorid'";
		$query5 = "SELECT * FROM item,category,stock,measure,requestsout WHERE item.iid=stock.iid AND item.cid=category.cid AND item.mid=measure.mid AND requestsout.iid=item.iid AND expire>now() AND requestsout.sorid='$sorid'";
		$result5 = mysqli_query($link,$query5);
		if(isset($_POST['add'])){
			$query2 = "UPDATE requestsout SET rStatus='Stocked Up' WHERE sorid='$sorid'";
			$result2 = mysqli_query($link,$query2);
		}
	}
	else{
		header('location:dashboard.php');
	}

	if(isset($_GET['sid']) AND isset($_GET['sorid'])){
		$sid = $_GET['sid'];
		$sorid = $_GET['sorid'];
		if($row = mysqli_fetch_assoc($result6)){
          $soquantity = $row['soquantity'];
          $soquantityLEFT = $row['soquantityLEFT'];
        }
       	$query7 = "SELECT * FROM stock WHERE sid='$sid'";
		$result7 = mysqli_query($link,$query7);
		if($row = mysqli_fetch_assoc($result7)){
          $quantity = $row['quantity'];
        }
        if($soquantityLEFT>$quantity){
        	$soquantity = $soquantity - $quantity;

        	$queryReportIN = "INSERT INTO soreport VALUES(NULL,'$sorid','$quantity',now());";
        	$resultReportIN = mysqli_query($link,$queryReportIN);

        	$queryQuan0 = "DELETE FROM stock WHERE sid='$sid';";
        	$resultQuan0 = mysqli_query($link,$queryQuan0);

        	$querySOquanUP = "UPDATE requestsout SET soquantityLEFT=(soquantityLEFT-'$quantity') WHERE sorid='$sorid';";
        	$resultSOquanUP = mysqli_query($link,$querySOquanUP);
        	$url = $_SERVER['REQUEST_URI'];
        	$url = strtok($url, '&');
			header('location:'.$url);
        }
        else if($soquantityLEFT<$quantity){
        	$quantity = $quantity - $soquantityLEFT;
        	// $soquantity=0;
        	$queryReportIN = "INSERT INTO soreport VALUES(NULL,'$sorid','$soquantityLEFT',now());";
        	$resultReportIN = mysqli_query($link,$queryReportIN);

        	$querySOquanOK = "UPDATE requestsout SET soquantityLEFT=0,sorStatus='Stocked Out' WHERE sorid='$sorid';";
        	$resultSOquanOK = mysqli_query($link,$querySOquanOK);

        	$queryQuanOK = "UPDATE stock SET quantity='$quantity' WHERE sid='$sid';";
        	$resultQuanOK = mysqli_query($link,$queryQuanOK);
        	$url = $_SERVER['REQUEST_URI'];
        	$url = strtok($url, '&');
			header('location:'.$url);
        }
        else if($soquantityLEFT==$quantity){
        	$queryReportIN = "INSERT INTO soreport VALUES(NULL,'$sorid','$soquantity',now());";
        	$resultReportIN = mysqli_query($link,$queryReportIN);

        	$querySOquanOK = "UPDATE requestsout SET soquantityLEFT=0,sorStatus='Stocked Out' WHERE sorid='$sorid';";
        	$resultSOquanOK = mysqli_query($link,$querySOquanOK);
        	
        	$queryQuan0 = "DELETE FROM stock WHERE sid='$sid';";
        	$resultQuan0 = mysqli_query($link,$queryQuan0);
        	$url = $_SERVER['REQUEST_URI'];
        	$url = strtok($url, '&');
			header('location:'.$url);
        }
	}	

	if(isset($_GET['iid'])){
		$iid = $_GET['iid'];
		$query4 = "SELECT * FROM item WHERE iid='$iid'";
		$result4 = mysqli_query($link,$query4);
		
	}


	$sql = "SELECT `iid`,`iname` FROM item";
	if($result = mysqli_query($link,$sql)){
		while($row = mysqli_fetch_assoc($result)){
			$user[] = $row;
		}
	}

	$queryCheckComplete = "SELECT soquantityLEFT FROM requestsout WHERE sorid='$sorid';";
	$resultCheckComplete = mysqli_query($link,$queryCheckComplete);
   if($row = mysqli_fetch_assoc($resultCheckComplete)){
		if($row['soquantityLEFT']==0){
			echo "<script>alert('Stock Out Successful');</script>";
			header("refresh:0.05;url=sorequestAdmin.php");
		}

    }
    require './html/stockOut.html';
 ?>