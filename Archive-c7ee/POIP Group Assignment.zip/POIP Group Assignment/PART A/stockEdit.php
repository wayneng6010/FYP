<?php 
	include 'verficationEP.php';

	require_once 'conn.php';


	if(isset($_POST['search'])){
		$fname = $_POST['fname'];
		$fname = mysqli_real_escape_string($link,$fname);
		$fname = htmlentities($fname, ENT_QUOTES, "UTF-8");
		$date = $_POST['date'];
		$quan = $_POST['quan'];
		(($quan=="HL")? $quan="DESC":$quan="ASC");
		(($date=="HL")? $date="DESC":$date="ASC");
		$sql2 = "SELECT i.iname,s.quantity,s.expire, m.mname, s.sStatus
				FROM stock as s, item as i, measure as m 
				WHERE s.iid = i.iid AND i.mid = m.mid AND i.iname LIKE '%$fname%'
				ORDER BY quantity $quan, expire $date;";
		$result2 = mysqli_query($link,$sql2);
	}
	else{
		$sql = "SELECT i.iname,s.quantity,s.expire, m.mname, s.sStatus 
				FROM stock as s, item as i, measure as m 
				WHERE s.iid = i.iid AND i.mid = m.mid;";
		$result = mysqli_query($link,$sql);
	}

	include 'html/stockEdit.html';
 ?>