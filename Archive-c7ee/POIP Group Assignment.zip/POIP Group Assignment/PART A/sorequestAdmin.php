<?php
	include 'verficationEP.php';
	
	$uid = $_SESSION['userID'];

	require_once 'conn.php';

	$sql = "SELECT * FROM requestsout 
			JOIN item ON requestsout.iid=item.iid 
			JOIN measure ON item.mid=measure.mid
			JOIN user ON requestsout.uid=user.uid";
	$result = mysqli_query($link,$sql);

	require './html/sorequestAdmin.html';
 ?>