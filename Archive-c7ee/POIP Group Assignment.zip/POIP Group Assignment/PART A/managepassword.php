<?php
	session_start();
	if(!isset($_SESSION['islogin'])){
		header('Location:index.php');
	} 
	if(isset($_SESSION['kickOut'])){
		echo "<script>alert('You have to change your password before you can access to the system')</script>";
	}

	require_once 'conn.php';
	$sql = "SELECT * FROM user WHERE uid = '$_SESSION[userID]'";
	$result = mysqli_query($link,$sql);
	$result1 = mysqli_query($link,$sql);
	$result3 = mysqli_query($link,$sql);

	if(isset($_POST['chgPW'])){
		$oldPw = $_POST['oldPw'];
		$newPw = $_POST['newPw'];
		$newPw2 = $_POST['newPw2'];

		if(!(password_verify($oldPw,$_SESSION['userPw']))){
			echo "<script>alert('Password incorrect');</script>";
		}
		else if($newPw != $newPw2){
			echo "<script>alert('New password not match');</script>";
		}
		else{
		$newHashPw = password_hash($newPw, PASSWORD_DEFAULT);
		$_SESSION['userPw'] = $newHashPw;
		$sql2 = "UPDATE user
				SET password ='$newHashPw'
				WHERE uid = '$_SESSION[userID]'";
		$result2 = mysqli_query($link,$sql2);
		echo "<script>alert('New password is set');</script>";
		$sql3 = mysqli_query($link,"UPDATE user SET firstlogin=1 WHERE uid = '$_SESSION[userID]'");
		$_SESSION['firstlogin'] = 1;
        while($row = mysqli_fetch_assoc($result3)){
        	if(!$row['firstlogin']){
				header('location:redirectFromManage.php');
        	}
        }		
		}
	}

	require './html/managepassword.html';

 ?>