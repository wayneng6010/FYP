<?php
	include 'verficationEP.php';
	
	require_once 'conn.php';

	if(isset($_POST['add'])){
		$item = $_POST['item'];
		$quantity = $_POST['quantity'];
		$exp = $_POST['exp'];
		$sql2 = "INSERT INTO stock VALUES (NULL, '$item', '$quantity', '$exp', 1)";
		if($queryResult = mysqli_query($link, $sql2)){
			echo "<script>alert('Stock up successful');</script>";
			header("refresh:0.001;url=stock.php");
		}
		else{
			echo "<script>alert('Failed');</script>";
		}
	}

	if(isset($_GET['rid'])){
		$rid = $_GET['rid'];
		$query1 = "SELECT * FROM item,request WHERE request.iid=item.iid AND request.rid='$rid'";
		$result1 = mysqli_query($link,$query1);
		$query3 = "SELECT * FROM item,request WHERE request.iid=item.iid AND request.rid='$rid'";
		$result3 = mysqli_query($link,$query1);
		$query5 = "SELECT * FROM item,request WHERE request.iid=item.iid AND request.rid='$rid'";
		$result5 = mysqli_query($link,$query5);
		if(isset($_POST['add'])){
            while($row = mysqli_fetch_assoc($result5)){
            	if(!$row['monthly']){
            		$query2 = "UPDATE request SET rStatus='Stocked Up' WHERE rid='$rid'";
					$result2 = mysqli_query($link,$query2);
					header("refresh:0.001;url=requestAdmin.php");
				}
				else{
					$nextMonth = date('Y-m-d', strtotime('first day of next month'));
					$query6 = "UPDATE request SET rStatus='Stocked Up',rDate='$nextMonth' WHERE rid='$rid'";
					$result6 = mysqli_query($link,$query6);
					header("refresh:0.001;url=requestAdmin.php");
				}
            }
			
			
		}
	}

	if(isset($_GET['iid'])){
		$iid = $_GET['iid'];
		$query4 = "SELECT * FROM item WHERE iid='$iid'";
		$result4 = mysqli_query($link,$query4);
		
	}


	$sql = "SELECT `iid`,`iname` FROM item";
	if($result = mysqli_query($link,$sql)){
		while($row = mysqli_fetch_assoc($result)){
			$user[] = $row;
		}
	}
	require './html/stock.html';
 ?>