<?php 
	include 'verficationEPUser.php';
	
	require_once 'conn.php';
	$sql = "SELECT * FROM item WHERE status=1";
	$result = mysqli_query($link,$sql);
	$sql1 = "SELECT * FROM measure";
	$result1 = mysqli_query($link,$sql1);

	if(isset($_POST['request'])){
		$itemName = $_POST['itemName'];
		$quantity = $_POST['quantity'];
		$purpose = $_POST['purpose'];
		$purpose = mysqli_real_escape_string($link,$purpose);
		$purpose = htmlentities($purpose, ENT_QUOTES, "UTF-8");
		$uid = $_SESSION['userID'];

		$sql2 = "INSERT INTO requestsout VALUES (null,'$uid','$itemName','$quantity','$quantity','$purpose',now(),'Pending')";
		if ($result2 = mysqli_query($link,$sql2)){
			echo "<script>alert('Request has been sent');</script>";
		}

	}

	require './html/requestStockOut.html';
 ?>