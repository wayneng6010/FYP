<?php 
	include 'verficationEPUser.php';
	
	require_once 'conn.php';
	$uid = $_SESSION['userID'];
	$sql = "SELECT * FROM requestsout JOIN item ON requestsout.iid=item.iid JOIN measure ON item.mid=measure.mid  WHERE uid='$uid'";
	$result = mysqli_query($link,$sql);

	require './html/itemStockOut.html';
 ?>