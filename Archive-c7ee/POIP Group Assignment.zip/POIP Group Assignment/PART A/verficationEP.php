<?php 
	session_start();
	if(!isset($_SESSION['islogin'])){
		$_SESSION['kickOut'] = "kick";
		header('Location:index.php');
	} 

	if($_SESSION['role']!=0){
		echo "<script>alert('Access Denied. You are not authorized to access to that page.')</script>";
		header("refresh:0.001;url=user.php");
	} 

	if($_SESSION['firstlogin']==0){
		$_SESSION['kickOut'] = "kick";
		header('Location:manage.php');
	} 
?>