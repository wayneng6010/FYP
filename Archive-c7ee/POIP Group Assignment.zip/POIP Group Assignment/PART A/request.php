<?php 
	include 'verficationEPUser.php';
	
	require_once 'conn.php';
	$sql = "SELECT * FROM item WHERE status=1";
	$result = mysqli_query($link,$sql);
	$sql1 = "SELECT * FROM measure";
	$result1 = mysqli_query($link,$sql1);

	if(isset($_POST['request'])){
		$itemName = $_POST['itemName'];
		$quantity = $_POST['quantity'];
		$purpose = $_POST['purpose'];
		$purpose = mysqli_real_escape_string($link,$purpose);
		$purpose = htmlentities($purpose, ENT_QUOTES, "UTF-8");
		if(isset($_POST['monthly'])){
			$monthly = $_POST['monthly'];
		}
		$uid = $_SESSION['userID'];

		if(isset($_POST['monthly'])){
			$date = date('Y-m-d', strtotime('first day of next month'));
			$sql2 = "INSERT INTO request VALUES (null,'$uid','$itemName','$quantity','$purpose','$date','Pending',1)";
			if ($result2 = mysqli_query($link,$sql2)){
				echo "<script>alert('Request has been sent');</script>";
				echo "<script>alert('Your request should be valid on the beginning of next month');</script>";
			}
		}
		else{
			$sql2 = "INSERT INTO request VALUES (null,'$uid','$itemName','$quantity','$purpose',now(),'Pending',0)";
			if ($result2 = mysqli_query($link,$sql2)){
				echo "<script>alert('Request has been sent');</script>";
			}
		}

	}

	require './html/request.html';
 ?>