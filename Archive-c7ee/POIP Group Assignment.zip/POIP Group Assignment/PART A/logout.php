<?php
	session_start() ;
	$id = $_SESSION['userID'];
	require_once 'conn.php';
	$loginrecord = mysqli_query($link,"UPDATE user SET `lastlogin`=NOW() WHERE `uid`='$id'");
	session_destroy() ;
	header('Location:index.php');
?>