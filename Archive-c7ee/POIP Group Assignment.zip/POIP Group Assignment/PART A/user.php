<?php 
	include 'verficationEPUser.php';

	require_once 'conn.php';

	$uid = $_SESSION['userID'];
	$sql = "SELECT COUNT(*) AS requestNo FROM request WHERE uid='$uid' AND monthly=0";
	$result = mysqli_query($link,$sql);
	$sql3 = "SELECT COUNT(*) AS requestNo FROM request WHERE uid='$uid' AND monthly=1";
	$result3 = mysqli_query($link,$sql3);
	
	$sql1 = "SELECT COUNT(*) AS requestNo FROM requestsout WHERE uid='$uid'";
	$result1 = mysqli_query($link,$sql1);

	$uid = $_SESSION['userID'];
	$sql2 = "SELECT * FROM user WHERE uid='$uid'";
	$result2 = mysqli_query($link,$sql2);
	require './html/user.html';
 ?>