<?php
	include 'verficationEP.php';

	require_once 'conn.php';
	$sql = "SELECT COUNT(*) AS requestNo FROM request WHERE rStatus='Pending' AND rDate<=now();";
	$result = mysqli_query($link,$sql);

	$sql1 = "SELECT COUNT(*) AS expiredItem FROM stock WHERE expire <= CURDATE() AND sStatus=1";
	$result1 = mysqli_query($link,$sql1);

	$sql2 = "SELECT *, SUM(quantity) AS sum FROM item,category,stock,measure WHERE item.iid=stock.iid AND item.cid=category.cid AND item.mid=measure.mid AND expire>now() GROUP BY iname";
	$result2 = mysqli_query($link,$sql2);

	$sql3 = "SELECT COUNT(*) As SOrequest FROM requestsout 
			JOIN item ON requestsout.iid=item.iid 
			JOIN measure ON item.mid=measure.mid
			JOIN user ON requestsout.uid=user.uid
			WHERE sorStatus='Pending';";
	$result3 = mysqli_query($link,$sql3);

	$uid = $_SESSION['userID'];
	$sql6 = "SELECT * FROM user WHERE uid='$uid'";
	$result6 = mysqli_query($link,$sql6);

	//for monthly request
	$date = date_create("now");
    $date = date_format($date,"d");
    $onceOnly=0;
	$dateTdy = date('Y-m-d', strtotime('first day of this month'));
    if($date==1){
    	$sql4 = "SELECT * FROM request WHERE monthly=1 AND rStatus='Stocked Up'";
		$result4 = mysqli_query($link,$sql4);
        while($row = mysqli_fetch_assoc($result4)){
        	if($row['rDate']==$dateTdy AND $onceOnly==0){
        		echo "<br>".$row['rid'];
        		$sql5 = "UPDATE request SET rStatus='Pending'";
				$result5 = mysqli_query($link,$sql5);
    			$onceOnly = 1;
    			header("Refresh:0");
        	}
        }
    }
	

	require './html/dashboard.html';
 ?>