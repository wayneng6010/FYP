<?php
	include 'verficationEP.php';
	
	$uid = $_SESSION['userID'];

	require_once 'conn.php';

	$sql = "SELECT * FROM request 
			JOIN item ON request.iid=item.iid 
			JOIN measure ON item.mid=measure.mid
			JOIN user ON request.uid=user.uid
			 WHERE monthly=0";
	$result = mysqli_query($link,$sql);

	$sql1 = "SELECT * FROM request 
			JOIN item ON request.iid=item.iid 
			JOIN measure ON item.mid=measure.mid
			JOIN user ON request.uid=user.uid
			 WHERE monthly=1";
	$result1 = mysqli_query($link,$sql1);

	require './html/requestAdmin.html';
 ?>