<?php 
	$link = mysqli_connect('localhost','root','','poip2');
	if(!$link)
		die('connection Error').mysqli_connect_error();
 ?>