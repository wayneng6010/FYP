<?php
	include 'verficationEP.php';

	require_once 'conn.php';
	$sql = "SELECT * FROM user";
	$result = mysqli_query($link,$sql);

	if(isset($_POST['searchUser'])){
		$role = $_POST['role'];
		$fname = $_POST['fname'];
		$fname = mysqli_real_escape_string($link,$fname);
		$fname = htmlentities($fname, ENT_QUOTES, "UTF-8");
		$sql2 = "SELECT * 
				FROM user 
				WHERE fname LIKE '%$fname%' AND role='$role'";
		$result2 = mysqli_query($link,$sql2);
	}

	if(isset($_GET['id'])){
		$id = $_GET['id'];
		$sql3 = "DELETE FROM user WHERE uid='$id';";
		if($itemresult1 = mysqli_query($link,$sql3)){
			echo "<script>alert('User has been removed');location.assign(userEdit.php);</script>";
			$url = $_SERVER['REQUEST_URI'];
         	$url = strtok($url, '?');
			header("refresh:0.05;url=".$url);
		}else{
			echo mysqli_error($link);
		}
	}

	require './html/userEdit.html';
?>