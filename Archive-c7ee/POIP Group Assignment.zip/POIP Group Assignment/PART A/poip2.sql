-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2018 at 11:28 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poip2`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cid` int(11) NOT NULL,
  `cname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cid`, `cname`) VALUES
(1, 'Apparatus'),
(2, 'Consumable'),
(3, 'Equipment'),
(4, 'Reagent');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `iid` int(11) NOT NULL,
  `iname` varchar(30) NOT NULL,
  `cid` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`iid`, `iname`, `cid`, `mid`, `status`) VALUES
(57, 'Alcohol Pad', 3, 3, 1),
(58, 'Aqua', 2, 4, 1),
(59, 'Sodium', 4, 4, 1),
(60, 'Retort Stand', 1, 1, 0),
(61, 'Mercury', 4, 1, 0),
(62, 'Chloride', 4, 1, 1),
(63, 'Beaker 10 ml', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `measure`
--

CREATE TABLE `measure` (
  `mid` int(11) NOT NULL,
  `mname` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `measure`
--

INSERT INTO `measure` (`mid`, `mname`) VALUES
(1, 'L'),
(2, 'g'),
(3, 'pcs'),
(4, 'ml'),
(5, 'kg'),
(6, 'mm'),
(8, 'unit');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `rid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `iid` int(11) NOT NULL,
  `quantity` decimal(11,2) NOT NULL,
  `purpose` longtext NOT NULL,
  `rDate` date DEFAULT NULL,
  `rStatus` text NOT NULL,
  `monthly` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`rid`, `uid`, `iid`, `quantity`, `purpose`, `rDate`, `rStatus`, `monthly`) VALUES
(20, 2, 56, '10.00', 'Nothing', '2018-04-20', 'Pending', 0),
(21, 2, 59, '10.00', 'Nothing', '2018-05-01', 'Pending', 1),
(22, 2, 56, '10.00', 'Nothing', '2018-04-20', 'Stocked Up', 0),
(27, 2, 57, '50.00', 'Testing', '2018-04-21', 'Pending', 0),
(28, 2, 56, '10.00', 'Nothing', '2018-04-21', 'Pending', 0);

-- --------------------------------------------------------

--
-- Table structure for table `requestsout`
--

CREATE TABLE `requestsout` (
  `sorid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `iid` int(11) NOT NULL,
  `soquantity` decimal(11,2) NOT NULL,
  `soquantityLEFT` decimal(11,2) NOT NULL,
  `sopurpose` longtext NOT NULL,
  `sorDate` date DEFAULT NULL,
  `sorStatus` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requestsout`
--

INSERT INTO `requestsout` (`sorid`, `uid`, `iid`, `soquantity`, `soquantityLEFT`, `sopurpose`, `sorDate`, `sorStatus`) VALUES
(79, 2, 57, '10.00', '5.00', 'Nothing', '2018-04-20', 'Pending'),
(80, 2, 56, '10.00', '0.00', 'Nothing', '2018-04-20', 'Stocked Out'),
(81, 2, 59, '10.00', '10.00', 'ABC', '2018-04-21', 'Pending'),
(82, 2, 62, '10.00', '0.00', 'Testing again', '2018-04-21', 'Stocked Out');

-- --------------------------------------------------------

--
-- Table structure for table `soreport`
--

CREATE TABLE `soreport` (
  `stockoutRid` int(11) NOT NULL,
  `sorid` int(11) NOT NULL,
  `stockoutQuan` decimal(11,2) NOT NULL,
  `stockoutDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `soreport`
--

INSERT INTO `soreport` (`stockoutRid`, `sorid`, `stockoutQuan`, `stockoutDate`) VALUES
(144, 80, '10.00', '2018-04-20'),
(145, 79, '5.00', '2018-04-21'),
(146, 82, '10.00', '2018-04-21');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `sid` int(11) NOT NULL,
  `iid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `expire` date NOT NULL,
  `sStatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`sid`, `iid`, `quantity`, `expire`, `sStatus`) VALUES
(132, 56, 100, '2018-04-30', 1),
(133, 57, 100, '2018-05-01', 1),
(134, 58, 100, '2018-04-30', 1),
(135, 59, 100, '2018-04-16', 0),
(136, 61, 100, '2018-04-16', 0),
(137, 58, 15, '2018-04-30', 1),
(139, 56, 5, '2018-04-23', 1),
(141, 57, 10, '2018-04-30', 1),
(142, 56, 10, '2018-04-24', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` int(11) NOT NULL,
  `firstlogin` tinyint(1) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastlogin` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `fname`, `password`, `email`, `role`, `firstlogin`, `created`, `lastlogin`) VALUES
(1, 'Admin', '$2y$10$FbJHBelTCW501shdI0wxqupbQsLR4u19hxIqTYUivGjrXF1FsjtKm', 'Admin', 0, 1, '2018-04-21 08:13:19', '2018-04-21 08:13:19'),
(2, 'user', '$2y$10$WbI9y8ac6balMd8ClQAsUOn.4JiEEa2bwBHORasg8ji2ixAzH7myy', 'user', 1, 1, '2018-04-21 08:15:54', '2018-04-21 07:34:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`iid`);

--
-- Indexes for table `measure`
--
ALTER TABLE `measure`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `requestsout`
--
ALTER TABLE `requestsout`
  ADD PRIMARY KEY (`sorid`);

--
-- Indexes for table `soreport`
--
ALTER TABLE `soreport`
  ADD PRIMARY KEY (`stockoutRid`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `iid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `measure`
--
ALTER TABLE `measure`
  MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `requestsout`
--
ALTER TABLE `requestsout`
  MODIFY `sorid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `soreport`
--
ALTER TABLE `soreport`
  MODIFY `stockoutRid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
